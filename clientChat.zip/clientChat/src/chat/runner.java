package chat;
/*
 * socket.io-java-client Test.java
 *
 * Copyright (c) 2012, Enno Boland
 * socket.io-java-client is a implementation of the socket.io protocol in Java.
 *
 * See LICENSE file for more information
 */

import io.socket.IOAcknowledge;
import io.socket.IOCallback;
import io.socket.SocketIO;
import io.socket.SocketIOException;

import java.util.Arrays;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class runner implements ChatCallbackAdapter {

    private SocketIO socket;

    /**
     * @param args
     */
    public runner() throws Exception {

        socket = new SocketIO();
        socket.connect("http://130.185.82.35:90", x);


// Emits an event to the server.

    }

    public static void main(String[] args) {
        try {
            new runner();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    IOCallback x = new IOCallback() {

        @Override
        public void onDisconnect() {
            //throw new UnsupportedOperationException("Not supported yet.");
            System.out.println("1");
        }

        @Override
        public void onConnect() {
            //throw new UnsupportedOperationException("Not supported yet.");
            System.out.println("2");
        }

        @Override
        public void onMessage(String data, IOAcknowledge ack) {
            //throw new UnsupportedOperationException("Not supported yet.");
            System.out.println("3");
        }

        @Override
        public void onMessage(JSONObject json, IOAcknowledge ack) {
            //throw new UnsupportedOperationException("Not supported yet.");
            System.out.println("4");
        }

        @Override
        public void on(String event, IOAcknowledge ack, Object... args) {
            //throw new UnsupportedOperationException("Not supported yet.");
            System.out.println("5");
            try {
                JSONArray data = new JSONArray(args);
                JSONObject x = data.toJSONObject(data);
                        System.out.println(data.toString().replace("\\", ""));
                if (event.equals("start2")) {
                    //System.out.println(data.getString("population") + ": " + x.get("maximum") + "   " + x.get("mutation") +"\n");
                    send();
                }
            } catch (JSONException ex) {
                ex.printStackTrace();
            }
        }

        @Override
        public void onError(SocketIOException socketIOException) {
            //throw new UnsupportedOperationException("Not supported yet.");
            socketIOException.printStackTrace();
            System.out.println("6");
        }
    };

    public void send() throws JSONException {
        JSONObject x = new JSONObject().put("value1", "155").put("value2", "180").put("value3", "-50").put("value4", "88").put("value5", "78").put("value6", "20");
        socket.emit("event", x);
    }

    @Override
    public void onDisconnect() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void onConnect() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void callback(JSONArray data) throws JSONException {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void on(String event, JSONObject data) {
    }

    @Override
    public void onMessage(String message) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void onMessage(JSONObject json) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void onConnectFailure() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}